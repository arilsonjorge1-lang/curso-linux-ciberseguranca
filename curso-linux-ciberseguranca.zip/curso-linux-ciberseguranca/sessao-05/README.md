# Sessão 05 — Análise de Vulnerabilidades em Linux e Ferramentas de Auditoria

**Curso:** Reskilling — Linux e Cibersegurança
**Objetivo de Aprendizagem:** OA5 — Criar
**Ambiente prático:** TryHackMe (Linux Process Analysis) + KillerCoda Ubuntu Playground

## Contexto

Execução de um exame de auditoria técnica automatizada com o **Lynis** para identificar
desvios de conformidade em relação aos standards de segurança recomendados
(CIS Benchmarks).

---

## Metodologia

1. Instalação do Lynis (`sudo apt update && sudo apt install lynis -y`)
2. Execução da auditoria completa do sistema (`sudo lynis audit system`)
3. Localização da secção de resultados finais (Hardening Index, Warnings, Suggestions)
4. Escolha de 2 Suggestions críticas nas áreas de **Authentication** ou **Filesystem**
5. Pesquisa da correção recomendada na base de dados oficial (Cisofy)

---

## Resultados

| Item | Valor |
|---|---|
| Hardening Score inicial | `<< PREENCHER: ex. 68/100 >>` |
| Nº de Warnings encontrados | `<< PREENCHER >>` |
| Nº de Suggestions encontradas | `<< PREENCHER >>` |

---

## Warnings/Suggestions Relevantes (Excerto do Lynis)

```
<< colar aqui o excerto relevante de /var/log/lynis-report.dat ou do output do terminal >>
```

---

## Vulnerabilidades Selecionadas e Correções Propostas

### 1. `<< Código do controlo, ex: AUTH-9262 >>` — `<< título da suggestion >>`

**Categoria:** Authentication / Filesystem
**Descrição do problema:** `<< o que o Lynis identificou >>`
**Porque é um risco:** `<< explicação do impacto de segurança >>`
**Referência Cisofy:** `https://cisofy.com/lynis/controls/<< CODIGO >>/`
**Correção proposta:**
```
<< comando(s) ou alteração de configuração recomendada >>
```

### 2. `<< Código do controlo >>` — `<< título da suggestion >>`

**Categoria:** Authentication / Filesystem
**Descrição do problema:** `<< o que o Lynis identificou >>`
**Porque é um risco:** `<< explicação do impacto de segurança >>`
**Referência Cisofy:** `https://cisofy.com/lynis/controls/<< CODIGO >>/`
**Correção proposta:**
```
<< comando(s) ou alteração de configuração recomendada >>
```

---

## Score Após Correções (opcional, se re-executado)

```
<< PREENCHER, se voltares a correr sudo lynis audit system --quick após aplicar as correções >>
```

---

## Ligação com Sessões Anteriores

- Verificar se os Warnings relativos a SSH (Sessão 04) e Firewall (Sessão 03) já não
aparecem, confirmando que o hardening aplicado anteriormente se mantém eficaz.

---

*Relatório elaborado no âmbito da Sessão 5 do percurso Reskilling — Linux e Cibersegurança.*
