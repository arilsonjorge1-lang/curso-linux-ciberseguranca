# Sessão 04 — Gestão Segura de Acessos Remotos SSH em Linux

**Curso:** Reskilling — Linux e Cibersegurança
**Objetivo de Aprendizagem:** OA4 — Aplicar
**Ambiente prático:** KillerCoda Ubuntu Playground

## Contexto

Proteger o canal de gestão remota do servidor Ubuntu, eliminando a autenticação
tradicional por password e migrando para autenticação criptográfica (chave Ed25519),
complementada com bloqueio de login root direto e mudança da porta padrão do SSH.

---

## Metodologia

1. Criação de um utilizador de teste (`testuser`) e preparação do diretório `.ssh`
2. Geração de um par de chaves Ed25519 (`ssh-keygen -t ed25519`)
3. Transferência da chave pública para o servidor (`ssh-copy-id`)
4. Teste do login por chave **antes** de qualquer alteração ao `sshd_config`
5. Edição do `sshd_config`: bloqueio de root, desativação de password, mudança de porta
6. Validação obrigatória da sintaxe (`sudo sshd -t`) antes do restart
7. Reinício do serviço SSH e resolução de um conflito com `ssh.socket`
8. Teste final de login por chave, na nova porta, confirmando o sucesso

---

## Resultados

### Utilizador de teste
```
testuser
```

### Chave gerada
```
Tipo: ed25519
Fingerprint: SHA256:W76wgnpn1sCqKR2KYXbzbZ4G2fUAaddAy1uyFWveIts root@ubuntu
```

### Linhas modificadas do sshd_config
```
PermitRootLogin no
PasswordAuthentication no
Port 2222
```

Confirmação via grep, sem duplicados:
```
$ grep -E "PermitRootLogin|PasswordAuthentication|^Port" /etc/ssh/sshd_config
PermitRootLogin no
PasswordAuthentication no
Port 2222
```

---

## Cópia Limpa do sshd_config Corrigido

Ficheiro completo, sem chaves privadas nem dados sensíveis (ambiente de lab
KillerCoda, configuração minimalista):

```
PermitRootLogin no
Subsystem sftp internal-sftp
PasswordAuthentication no
Port 2222
```

---

## Validação da Configuração

```
$ sudo sshd -t
(sem output — sintaxe válida)
```

---

## Reinício do Serviço — Nota Técnica Importante

Ao reiniciar o serviço com `sudo systemctl restart sshd`, foi encontrado o erro:
```
Unit sshd.service could not be found.
```

No Ubuntu/Debian o serviço chama-se **ssh**, não sshd (diferente de distribuições
baseadas em RHEL). Após corrigir para `systemctl restart ssh`, o serviço reiniciou,
mas continuou a escutar na porta 22 em vez da 2222 configurada.

**Causa:** o Ubuntu moderno usa **ativação por socket do systemd** (`ssh.socket`), que
define a sua própria porta de escuta e sobrepõe-se ao valor `Port` definido no
`sshd_config`.

**Correção aplicada:**
```bash
sudo systemctl disable --now ssh.socket
sudo systemctl enable --now ssh.service
sudo systemctl restart ssh.service
```

Confirmação nos logs do systemd:
```
sshd[2109]: Server listening on 0.0.0.0 port 2222.
sshd[2109]: Server listening on :: port 2222.
```

---

## Evidência de Login Bem-Sucedido via Chave

```
$ ssh -i ~/.ssh/id_ed25519 -p 2222 testuser@localhost
Last login: Wed Jul 22 12:28:35 2026 from 127.0.0.1
testuser@ubuntu:~$
```

Login confirmado:
- ✅ Via chave privada, sem qualquer pedido de password
- ✅ Na porta 2222 (porta padrão desativada)
- ✅ Como utilizador normal (login root direto bloqueado)

---

## Justificação das Escolhas

**PasswordAuthentication no:** elimina por completo o vetor de força bruta —
sem password para adivinhar, não há ataque de força bruta possível, independentemente
do número de tentativas.

**PermitRootLogin no:** obriga a autenticação com um utilizador normal seguida de
escalada explícita via `sudo`, o que fica registado em log — reduz o impacto imediato
de uma eventual chave comprometida e melhora a rastreabilidade de ações administrativas.

**Port 2222:** não é segurança "real" (security through obscurity), mas reduz
drasticamente o ruído de scanners automáticos e bots que testam apenas a porta 22
por defeito.

**Chave Ed25519 em vez de password:** um par de chaves criptográficas não pode ser
"adivinhado" por tentativa e erro — o espaço de possibilidades é astronomicamente
grande, tornando o brute-force matematicamente inviável.

---

## Checklist de Segurança Seguido

- [x] Chave gerada e testada com sucesso **antes** de desativar a autenticação por password
- [x] Sintaxe do `sshd_config` validada com `sshd -t` antes do restart
- [x] Sessão original mantida ativa até confirmação do novo acesso
- [x] Teste final de login realizado com a chave, na nova porta, com sucesso confirmado

---

*Relatório elaborado no âmbito da Sessão 4 do percurso Reskilling — Linux e Cibersegurança.*
